<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Recaptcha Implementation</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="styles.css">

        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    </head>
    <body>
        <h2>Homepage</h2>
        <div class="option">
            <a href="contact.php" class="box">Contact</a>
        </div>
        <div class="option">
            <a href="login.php" class="box">Login</a>
        </div>
        
    </body>
</html>